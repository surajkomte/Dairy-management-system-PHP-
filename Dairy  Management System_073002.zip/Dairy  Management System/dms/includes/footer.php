            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
<p>Developed By<a href="#" class="text-dark">suraj@dev</a></p>
                        </div>
                    </div>
                </footer>
            </div>